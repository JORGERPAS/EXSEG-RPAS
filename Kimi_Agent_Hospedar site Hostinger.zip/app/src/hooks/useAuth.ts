import { useState, useCallback, useEffect } from 'react';
import type { User, UserRole } from '@/types';

// Super Admin credentials (stored securely in memory only)
const SUPER_ADMIN_CREDENTIALS = {
  username: 'supervisorpas',
  password: '28129900jj'
};

// Mock users database (in production, this would be on a backend)
let usersDatabase: User[] = [];

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Check for existing session on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('exseg_user');
    if (savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser);
        setUser(parsedUser);
        setIsAuthenticated(true);
      } catch {
        localStorage.removeItem('exseg_user');
      }
    }
  }, []);

  const login = useCallback(async (username: string, password: string): Promise<boolean> => {
    // Check Super Admin credentials
    if (username === SUPER_ADMIN_CREDENTIALS.username && password === SUPER_ADMIN_CREDENTIALS.password) {
      const superAdmin: User = {
        id: 'superadmin-001',
        username: SUPER_ADMIN_CREDENTIALS.username,
        name: 'Super Administrador',
        role: 'superadmin',
        projectIds: ['all'],
        createdAt: new Date().toISOString()
      };
      setUser(superAdmin);
      setIsAuthenticated(true);
      localStorage.setItem('exseg_user', JSON.stringify(superAdmin));
      return true;
    }

    // Check regular users
    const foundUser = usersDatabase.find(
      u => u.username === username
    );

    // In production, passwords would be hashed and verified on backend
    // For demo purposes, we'll check against a simple mock
    if (foundUser) {
      // Mock password verification (in production, this would be hashed)
      const mockPassword = `pass-${username}`;
      if (password === mockPassword) {
        setUser(foundUser);
        setIsAuthenticated(true);
        localStorage.setItem('exseg_user', JSON.stringify(foundUser));
        return true;
      }
    }

    return false;
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('exseg_user');
  }, []);

  const createUser = useCallback((userData: Omit<User, 'id' | 'createdAt'> & { password: string }): User => {
    const newUser: User = {
      ...userData,
      id: `user-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    usersDatabase.push(newUser);
    return newUser;
  }, []);

  const deleteUser = useCallback((userId: string): boolean => {
    const initialLength = usersDatabase.length;
    usersDatabase = usersDatabase.filter(u => u.id !== userId);
    return usersDatabase.length < initialLength;
  }, []);

  const getUsersByRole = useCallback((role: UserRole): User[] => {
    return usersDatabase.filter(u => u.role === role);
  }, []);

  const getUsersByProject = useCallback((projectId: string): User[] => {
    return usersDatabase.filter(u => u.projectIds.includes(projectId));
  }, []);

  const updateUserProjects = useCallback((userId: string, projectIds: string[]): boolean => {
    const userIndex = usersDatabase.findIndex(u => u.id === userId);
    if (userIndex !== -1) {
      usersDatabase[userIndex].projectIds = projectIds;
      return true;
    }
    return false;
  }, []);

  return {
    user,
    isAuthenticated,
    login,
    logout,
    createUser,
    deleteUser,
    getUsersByRole,
    getUsersByProject,
    updateUserProjects
  };
}

export type AuthHook = ReturnType<typeof useAuth>;
