import { useState, useCallback } from 'react';
import type { GeneratedLink, ExpirationOption, Stream } from '@/types';

// Links database (in production, this would be on a backend)
let linksDatabase: GeneratedLink[] = [];

const EXPIRATION_VALUES: Record<ExpirationOption, number | null> = {
  '24h': 24 * 60 * 60 * 1000,
  '3d': 3 * 24 * 60 * 60 * 1000,
  '7d': 7 * 24 * 60 * 60 * 1000,
  '30d': 30 * 24 * 60 * 60 * 1000,
  '90d': 90 * 24 * 60 * 60 * 1000,
  '6m': 180 * 24 * 60 * 60 * 1000,
  '1y': 365 * 24 * 60 * 60 * 1000,
  'unlimited': null
};

export function useLinks() {
  const [links, setLinks] = useState<GeneratedLink[]>(linksDatabase);

  const generateLink = useCallback((
    stream: Stream, 
    expiration: ExpirationOption, 
    createdBy: string
  ): GeneratedLink => {
    const token = `token-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const expirationMs = EXPIRATION_VALUES[expiration];
    const expiresAt = expirationMs ? new Date(Date.now() + expirationMs).toISOString() : null;

    const newLink: GeneratedLink = {
      id: `link-${Date.now()}`,
      streamId: stream.id,
      streamName: stream.name,
      token,
      expiresAt,
      createdAt: new Date().toISOString(),
      createdBy
    };

    linksDatabase.push(newLink);
    setLinks([...linksDatabase]);
    return newLink;
  }, []);

  const deleteLink = useCallback((linkId: string): boolean => {
    const initialLength = linksDatabase.length;
    linksDatabase = linksDatabase.filter(l => l.id !== linkId);
    setLinks([...linksDatabase]);
    return linksDatabase.length < initialLength;
  }, []);

  const getLinkByToken = useCallback((token: string): GeneratedLink | undefined => {
    return linksDatabase.find(l => l.token === token);
  }, []);

  const isLinkValid = useCallback((link: GeneratedLink): boolean => {
    if (!link.expiresAt) return true;
    return new Date(link.expiresAt) > new Date();
  }, []);

  const getTimeRemaining = useCallback((link: GeneratedLink): { days: number; hours: number; minutes: number; seconds: number; total: number; isExpired: boolean } => {
    if (!link.expiresAt) {
      return { days: 0, hours: 0, minutes: 0, seconds: 0, total: Infinity, isExpired: false };
    }

    const now = new Date().getTime();
    const expires = new Date(link.expiresAt).getTime();
    const total = expires - now;

    if (total <= 0) {
      return { days: 0, hours: 0, minutes: 0, seconds: 0, total: 0, isExpired: true };
    }

    const days = Math.floor(total / (1000 * 60 * 60 * 24));
    const hours = Math.floor((total % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((total % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((total % (1000 * 60)) / 1000);

    return { days, hours, minutes, seconds, total, isExpired: false };
  }, []);

  const getLinksByCreator = useCallback((creatorId: string): GeneratedLink[] => {
    return linksDatabase.filter(l => l.createdBy === creatorId);
  }, []);

  const cleanupExpiredLinks = useCallback((): number => {
    const initialLength = linksDatabase.length;
    linksDatabase = linksDatabase.filter(l => isLinkValid(l));
    setLinks([...linksDatabase]);
    return initialLength - linksDatabase.length;
  }, [isLinkValid]);

  return {
    links,
    generateLink,
    deleteLink,
    getLinkByToken,
    isLinkValid,
    getTimeRemaining,
    getLinksByCreator,
    cleanupExpiredLinks
  };
}

export type LinksHook = ReturnType<typeof useLinks>;
