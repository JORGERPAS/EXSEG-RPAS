import { useState, useCallback } from 'react';
import type { Project, Stream } from '@/types';

// Predefined streams from requirements
const PREDEFINED_STREAMS: Stream[] = [
  { id: 'stream-001', name: 'JJrpa001', url: 'https://whep.flue.live/?stream=JJrpa001', projectId: '' },
  { id: 'stream-002', name: 'JJrpa002', url: 'https://whep.flue.live/?stream=JJrpa002', projectId: '' },
  { id: 'stream-003', name: 'JJrpa003', url: 'https://whep.flue.live/?stream=JJrpa003', projectId: '' },
  { id: 'stream-004', name: 'JJrpa001-Record', url: 'https://perry.flue.live/?stream=JJrpa001&record', projectId: '' },
  { id: 'stream-005', name: 'JORGEX2001', url: 'https://whep.flue.live/?stream=JORGEX2001', projectId: '' },
  { id: 'stream-006', name: 'JORGEX2002', url: 'https://whep.flue.live/?stream=JORGEX2002', projectId: '' },
  { id: 'stream-007', name: 'JORGEX2003', url: 'https://whep.flue.live/?stream=JORGEX2003', projectId: '' },
  { id: 'stream-008', name: 'JORGEX2001-Record', url: 'https://perry.flue.live/?stream=JORGEX2001&record', projectId: '' },
];

// Mock projects database
let projectsDatabase: Project[] = [
  {
    id: 'proj-001',
    name: 'Operação Alfa',
    description: 'Monitoramento área industrial Norte',
    streams: PREDEFINED_STREAMS.slice(0, 4),
    createdAt: new Date().toISOString()
  },
  {
    id: 'proj-002',
    name: 'Operação Beta',
    description: 'Monitoramento área portuária',
    streams: PREDEFINED_STREAMS.slice(4, 8),
    createdAt: new Date().toISOString()
  }
];

export function useProjects() {
  const [projects, setProjects] = useState<Project[]>(projectsDatabase);

  const createProject = useCallback((name: string, description: string, streamIds?: string[]): Project => {
    const selectedStreams = streamIds 
      ? PREDEFINED_STREAMS.filter(s => streamIds.includes(s.id)).map(s => ({ ...s, projectId: `proj-${Date.now()}` }))
      : [];
    
    const newProject: Project = {
      id: `proj-${Date.now()}`,
      name,
      description,
      streams: selectedStreams,
      createdAt: new Date().toISOString()
    };
    
    projectsDatabase.push(newProject);
    setProjects([...projectsDatabase]);
    return newProject;
  }, []);

  const deleteProject = useCallback((projectId: string): boolean => {
    const initialLength = projectsDatabase.length;
    projectsDatabase = projectsDatabase.filter(p => p.id !== projectId);
    setProjects([...projectsDatabase]);
    return projectsDatabase.length < initialLength;
  }, []);

  const getProjectById = useCallback((projectId: string): Project | undefined => {
    return projectsDatabase.find(p => p.id === projectId);
  }, []);

  const getAllStreams = useCallback((): Stream[] => {
    return PREDEFINED_STREAMS;
  }, []);

  const assignStreamsToProject = useCallback((projectId: string, streamIds: string[]): boolean => {
    const projectIndex = projectsDatabase.findIndex(p => p.id === projectId);
    if (projectIndex !== -1) {
      const selectedStreams = PREDEFINED_STREAMS
        .filter(s => streamIds.includes(s.id))
        .map(s => ({ ...s, projectId }));
      projectsDatabase[projectIndex].streams = selectedStreams;
      setProjects([...projectsDatabase]);
      return true;
    }
    return false;
  }, []);

  return {
    projects,
    createProject,
    deleteProject,
    getProjectById,
    getAllStreams,
    assignStreamsToProject
  };
}

export type ProjectsHook = ReturnType<typeof useProjects>;
