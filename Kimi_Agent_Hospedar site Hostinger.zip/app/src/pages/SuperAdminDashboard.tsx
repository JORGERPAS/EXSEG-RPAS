import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Header } from '@/components/Header';
import { UserManagement } from '@/components/UserManagement';
import { ProjectManagement } from '@/components/ProjectManagement';
import { LinkGenerator } from '@/components/LinkGenerator';
import { StreamGrid } from '@/components/StreamGrid';
import { useAuthContext } from '@/contexts/AuthContext';
import { useProjectsContext } from '@/contexts/ProjectsContext';
import { Users, FolderOpen, Link2, LayoutGrid, Shield } from 'lucide-react';

export function SuperAdminDashboard() {
  const { user, logout } = useAuthContext();
  const { getAllStreams } = useProjectsContext();
  const [activeTab, setActiveTab] = useState('dashboard');

  if (!user) return null;

  const allStreams = getAllStreams();

  return (
    <div className="min-h-screen bg-[hsl(var(--background))]">
      <Header 
        userName={user.name} 
        userRole={user.role} 
        onLogout={logout} 
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-[hsl(var(--exseg-dark))] flex items-center gap-2">
            <Shield className="h-6 w-6 text-[hsl(var(--exseg-gold))]" />
            Painel do Super Administrador
          </h2>
          <p className="text-[hsl(var(--exseg-gray))]">
            Gerenciamento completo do sistema EXSEG RPAS
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid grid-cols-2 md:grid-cols-5 gap-2 bg-[hsl(var(--muted))] p-1">
            <TabsTrigger value="dashboard" className="flex items-center gap-2 data-[state=active]:bg-white">
              <LayoutGrid className="h-4 w-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </TabsTrigger>
            <TabsTrigger value="projects" className="flex items-center gap-2 data-[state=active]:bg-white">
              <FolderOpen className="h-4 w-4" />
              <span className="hidden sm:inline">Projetos</span>
            </TabsTrigger>
            <TabsTrigger value="admins" className="flex items-center gap-2 data-[state=active]:bg-white">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Admins</span>
            </TabsTrigger>
            <TabsTrigger value="pilots" className="flex items-center gap-2 data-[state=active]:bg-white">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Pilotos</span>
            </TabsTrigger>
            <TabsTrigger value="links" className="flex items-center gap-2 data-[state=active]:bg-white">
              <Link2 className="h-4 w-4" />
              <span className="hidden sm:inline">Links</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-4">
            <div className="bg-white rounded-lg shadow-exseg overflow-hidden">
              <div className="p-4 border-b border-[hsl(var(--border))]">
                <h3 className="text-lg font-semibold text-[hsl(var(--exseg-dark))]">
                  Monitoramento em Tempo Real
                </h3>
                <p className="text-sm text-[hsl(var(--exseg-gray))]">
                  Todas as streams do sistema
                </p>
              </div>
              <StreamGrid streams={allStreams} />
            </div>
          </TabsContent>

          <TabsContent value="projects">
            <ProjectManagement />
          </TabsContent>

          <TabsContent value="admins">
            <UserManagement roleFilter="admin" />
          </TabsContent>

          <TabsContent value="pilots">
            <UserManagement roleFilter="pilot" />
          </TabsContent>

          <TabsContent value="links">
            <LinkGenerator />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
