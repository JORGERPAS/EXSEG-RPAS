import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, Clock } from 'lucide-react';
import { useLinksContext } from '@/contexts/LinksContext';
import { CountdownTimer } from '@/components/CountdownTimer';

export function PublicStream() {
  const { token } = useParams<{ token: string }>();
  const { getLinkByToken, isLinkValid } = useLinksContext();
  const [link, setLink] = useState<ReturnType<typeof getLinkByToken>>(undefined);
  const [isValid, setIsValid] = useState(true);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (token) {
      const foundLink = getLinkByToken(token);
      setLink(foundLink);
      setIsValid(foundLink ? isLinkValid(foundLink) : false);
      setIsLoading(false);
    }
  }, [token, getLinkByToken, isLinkValid]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[hsl(var(--exseg-dark))]">
        <div className="animate-spin h-8 w-8 border-4 border-[hsl(var(--exseg-gold))] border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!link || !isValid) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6">
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {!link 
                  ? 'Link não encontrado.' 
                  : 'Este link expirou e não está mais disponível.'}
              </AlertDescription>
            </Alert>
            <div className="mt-4 text-center">
              <img 
                src="/logo-exseg.png" 
                alt="EXSEG Logo" 
                className="h-12 object-contain mx-auto opacity-50"
              />
              <p className="mt-2 text-sm text-[hsl(var(--exseg-gray))]">
                EXSEG RPAS - Monitoramento de Operações
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Reconstruct stream URL from token
  const streamUrls: Record<string, string> = {
    'JJrpa001': 'https://whep.flue.live/?stream=JJrpa001',
    'JJrpa002': 'https://whep.flue.live/?stream=JJrpa002',
    'JJrpa003': 'https://whep.flue.live/?stream=JJrpa003',
    'JJrpa001-Record': 'https://perry.flue.live/?stream=JJrpa001&record',
    'JORGEX2001': 'https://whep.flue.live/?stream=JORGEX2001',
    'JORGEX2002': 'https://whep.flue.live/?stream=JORGEX2002',
    'JORGEX2003': 'https://whep.flue.live/?stream=JORGEX2003',
    'JORGEX2001-Record': 'https://perry.flue.live/?stream=JORGEX2001&record',
  };

  const streamUrl = streamUrls[link.streamName] || '';

  return (
    <div className="min-h-screen bg-[hsl(var(--exseg-dark))]">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14">
            <img 
              src="/logo-exseg.png" 
              alt="EXSEG Logo" 
              className="h-8 object-contain"
            />
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-[hsl(var(--exseg-gold))]" />
              <CountdownTimer expiresAt={link.expiresAt} />
            </div>
          </div>
        </div>
      </header>

      {/* Stream */}
      <main className="p-4">
        <div className="max-w-7xl mx-auto">
          <div className="relative bg-black rounded-lg overflow-hidden shadow-2xl" style={{ height: 'calc(100vh - 6rem)' }}>
            {/* Stream Header */}
            <div className="absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black/70 to-transparent p-4">
              <div className="flex items-center justify-between">
                <span className="text-white font-medium">
                  {link.streamName}
                </span>
                <span className="flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-3 w-3 rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                </span>
              </div>
            </div>

            {/* Iframe */}
            <iframe
              src={streamUrl}
              title={link.streamName}
              allowFullScreen
              sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
              className="w-full h-full border-0"
            />
          </div>
        </div>
      </main>
    </div>
  );
}
