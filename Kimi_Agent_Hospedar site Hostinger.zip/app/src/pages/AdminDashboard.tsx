import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Header } from '@/components/Header';
import { LinkGenerator } from '@/components/LinkGenerator';
import { StreamGrid } from '@/components/StreamGrid';
import { useAuthContext } from '@/contexts/AuthContext';
import { useProjectsContext } from '@/contexts/ProjectsContext';
import { LayoutGrid, Link2, FolderOpen, User } from 'lucide-react';

export function AdminDashboard() {
  const { user, logout } = useAuthContext();
  const { getProjectsForUser } = useProjectsContext();
  const [activeTab, setActiveTab] = useState('projects');

  if (!user) return null;

  const userProjects = getProjectsForUser(user.projectIds);
  const [selectedProject, setSelectedProject] = useState(userProjects[0]?.id || '');

  const currentProject = userProjects.find(p => p.id === selectedProject);
  const projectStreams = currentProject?.streams || [];

  return (
    <div className="min-h-screen bg-[hsl(var(--background))]">
      <Header 
        userName={user.name} 
        userRole={user.role} 
        onLogout={logout} 
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-[hsl(var(--exseg-dark))] flex items-center gap-2">
            <User className="h-6 w-6 text-[hsl(var(--exseg-blue))]" />
            Painel do Administrador
          </h2>
          <p className="text-[hsl(var(--exseg-gray))]">
            Gerenciamento dos seus projetos
          </p>
        </div>

        {/* Project Selector */}
        {userProjects.length > 1 && (
          <Card className="mb-6 border-[hsl(var(--exseg-blue))]/20">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <FolderOpen className="h-5 w-5 text-[hsl(var(--exseg-blue))]" />
                Selecionar Projeto
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {userProjects.map((project) => (
                  <button
                    key={project.id}
                    onClick={() => setSelectedProject(project.id)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                      selectedProject === project.id
                        ? 'bg-[hsl(var(--exseg-blue))] text-white'
                        : 'bg-[hsl(var(--muted))] text-[hsl(var(--exseg-dark))] hover:bg-[hsl(var(--exseg-blue))]/10'
                    }`}
                  >
                    {project.name}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid grid-cols-3 gap-2 bg-[hsl(var(--muted))] p-1">
            <TabsTrigger value="projects" className="flex items-center gap-2 data-[state=active]:bg-white">
              <FolderOpen className="h-4 w-4" />
              <span className="hidden sm:inline">Projeto</span>
            </TabsTrigger>
            <TabsTrigger value="dashboard" className="flex items-center gap-2 data-[state=active]:bg-white">
              <LayoutGrid className="h-4 w-4" />
              <span className="hidden sm:inline">Monitoramento</span>
            </TabsTrigger>
            <TabsTrigger value="links" className="flex items-center gap-2 data-[state=active]:bg-white">
              <Link2 className="h-4 w-4" />
              <span className="hidden sm:inline">Links</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="projects" className="space-y-4">
            {currentProject ? (
              <Card className="border-[hsl(var(--exseg-blue))]/20">
                <CardHeader>
                  <CardTitle className="text-xl">{currentProject.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-[hsl(var(--exseg-gray))]">{currentProject.description}</p>
                  <div className="mt-4 flex items-center gap-4">
                    <div className="bg-[hsl(var(--muted))] px-4 py-2 rounded-lg">
                      <span className="text-sm text-[hsl(var(--exseg-gray))]">Streams</span>
                      <p className="text-2xl font-bold text-[hsl(var(--exseg-blue))]">
                        {currentProject.streams.length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-[hsl(var(--exseg-blue))]/20">
                <CardContent className="py-8 text-center">
                  <p className="text-[hsl(var(--exseg-gray))]">
                    Nenhum projeto atribuído a você.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="dashboard" className="space-y-4">
            {projectStreams.length > 0 ? (
              <div className="bg-white rounded-lg shadow-exseg overflow-hidden">
                <div className="p-4 border-b border-[hsl(var(--border))]">
                  <h3 className="text-lg font-semibold text-[hsl(var(--exseg-dark))]">
                    Streams do Projeto: {currentProject?.name}
                  </h3>
                </div>
                <StreamGrid streams={projectStreams} />
              </div>
            ) : (
              <Card className="border-[hsl(var(--exseg-blue))]/20">
                <CardContent className="py-8 text-center">
                  <p className="text-[hsl(var(--exseg-gray))]">
                    Nenhuma stream configurada para este projeto.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="links">
            {selectedProject ? (
              <LinkGenerator projectId={selectedProject} />
            ) : (
              <Card className="border-[hsl(var(--exseg-blue))]/20">
                <CardContent className="py-8 text-center">
                  <p className="text-[hsl(var(--exseg-gray))]">
                    Selecione um projeto para gerar links.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
