import React, { createContext, useContext, useState, useCallback } from 'react';
import type { Project, Stream } from '@/types';

interface ProjectsContextType {
  projects: Project[];
  createProject: (name: string, description: string, streamIds?: string[]) => Project;
  deleteProject: (projectId: string) => boolean;
  getProjectById: (projectId: string) => Project | undefined;
  getAllStreams: () => Stream[];
  assignStreamsToProject: (projectId: string, streamIds: string[]) => boolean;
  getProjectsForUser: (projectIds: string[]) => Project[];
}

const ProjectsContext = createContext<ProjectsContextType | undefined>(undefined);

// Predefined streams
const PREDEFINED_STREAMS: Stream[] = [
  { id: 'stream-001', name: 'JJrpa001', url: 'https://whep.flue.live/?stream=JJrpa001', projectId: '' },
  { id: 'stream-002', name: 'JJrpa002', url: 'https://whep.flue.live/?stream=JJrpa002', projectId: '' },
  { id: 'stream-003', name: 'JJrpa003', url: 'https://whep.flue.live/?stream=JJrpa003', projectId: '' },
  { id: 'stream-004', name: 'JJrpa001-Record', url: 'https://perry.flue.live/?stream=JJrpa001&record', projectId: '' },
  { id: 'stream-005', name: 'JORGEX2001', url: 'https://whep.flue.live/?stream=JORGEX2001', projectId: '' },
  { id: 'stream-006', name: 'JORGEX2002', url: 'https://whep.flue.live/?stream=JORGEX2002', projectId: '' },
  { id: 'stream-007', name: 'JORGEX2003', url: 'https://whep.flue.live/?stream=JORGEX2003', projectId: '' },
  { id: 'stream-008', name: 'JORGEX2001-Record', url: 'https://perry.flue.live/?stream=JORGEX2001&record', projectId: '' },
];

// Mock projects database
let projectsDatabase: Project[] = [
  {
    id: 'proj-001',
    name: 'Operação Alfa',
    description: 'Monitoramento área industrial Norte',
    streams: PREDEFINED_STREAMS.slice(0, 4).map(s => ({ ...s, projectId: 'proj-001' })),
    createdAt: new Date().toISOString()
  },
  {
    id: 'proj-002',
    name: 'Operação Beta',
    description: 'Monitoramento área portuária',
    streams: PREDEFINED_STREAMS.slice(4, 8).map(s => ({ ...s, projectId: 'proj-002' })),
    createdAt: new Date().toISOString()
  }
];

export function ProjectsProvider({ children }: { children: React.ReactNode }) {
  const [projects, setProjects] = useState<Project[]>(projectsDatabase);

  const createProject = useCallback((name: string, description: string, streamIds?: string[]): Project => {
    const selectedStreams = streamIds 
      ? PREDEFINED_STREAMS.filter(s => streamIds.includes(s.id)).map(s => ({ ...s, projectId: `proj-${Date.now()}` }))
      : [];
    
    const newProject: Project = {
      id: `proj-${Date.now()}`,
      name,
      description,
      streams: selectedStreams,
      createdAt: new Date().toISOString()
    };
    
    projectsDatabase.push(newProject);
    setProjects([...projectsDatabase]);
    return newProject;
  }, []);

  const deleteProject = useCallback((projectId: string): boolean => {
    const initialLength = projectsDatabase.length;
    projectsDatabase = projectsDatabase.filter(p => p.id !== projectId);
    setProjects([...projectsDatabase]);
    return projectsDatabase.length < initialLength;
  }, []);

  const getProjectById = useCallback((projectId: string): Project | undefined => {
    return projectsDatabase.find(p => p.id === projectId);
  }, []);

  const getAllStreams = useCallback((): Stream[] => {
    return PREDEFINED_STREAMS;
  }, []);

  const assignStreamsToProject = useCallback((projectId: string, streamIds: string[]): boolean => {
    const projectIndex = projectsDatabase.findIndex(p => p.id === projectId);
    if (projectIndex !== -1) {
      const selectedStreams = PREDEFINED_STREAMS
        .filter(s => streamIds.includes(s.id))
        .map(s => ({ ...s, projectId }));
      projectsDatabase[projectIndex].streams = selectedStreams;
      setProjects([...projectsDatabase]);
      return true;
    }
    return false;
  }, []);

  const getProjectsForUser = useCallback((projectIds: string[]): Project[] => {
    if (projectIds.includes('all')) return projectsDatabase;
    return projectsDatabase.filter(p => projectIds.includes(p.id));
  }, []);

  return (
    <ProjectsContext.Provider value={{
      projects,
      createProject,
      deleteProject,
      getProjectById,
      getAllStreams,
      assignStreamsToProject,
      getProjectsForUser
    }}>
      {children}
    </ProjectsContext.Provider>
  );
}

export function useProjectsContext() {
  const context = useContext(ProjectsContext);
  if (context === undefined) {
    throw new Error('useProjectsContext must be used within a ProjectsProvider');
  }
  return context;
}
