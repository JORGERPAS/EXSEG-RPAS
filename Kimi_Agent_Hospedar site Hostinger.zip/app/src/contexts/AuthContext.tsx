import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import type { User, UserRole } from '@/types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  createUser: (userData: Omit<User, 'id' | 'createdAt'> & { password: string }) => User;
  deleteUser: (userId: string) => boolean;
  getUsersByRole: (role: UserRole) => User[];
  getUsersByProject: (projectId: string) => User[];
  updateUserProjects: (userId: string, projectIds: string[]) => boolean;
  getAllUsers: () => User[];
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Super Admin credentials
const SUPER_ADMIN_CREDENTIALS = {
  username: 'supervisorpas',
  password: '28129900jj'
};

// Mock users database
let usersDatabase: User[] = [];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const savedUser = localStorage.getItem('exseg_user');
    if (savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser);
        setUser(parsedUser);
        setIsAuthenticated(true);
      } catch {
        localStorage.removeItem('exseg_user');
      }
    }
  }, []);

  const login = useCallback(async (username: string, password: string): Promise<boolean> => {
    if (username === SUPER_ADMIN_CREDENTIALS.username && password === SUPER_ADMIN_CREDENTIALS.password) {
      const superAdmin: User = {
        id: 'superadmin-001',
        username: SUPER_ADMIN_CREDENTIALS.username,
        name: 'Super Administrador',
        role: 'superadmin',
        projectIds: ['all'],
        createdAt: new Date().toISOString()
      };
      setUser(superAdmin);
      setIsAuthenticated(true);
      localStorage.setItem('exseg_user', JSON.stringify(superAdmin));
      return true;
    }

    const foundUser = usersDatabase.find(u => u.username === username);
    if (foundUser) {
      const mockPassword = `pass-${username}`;
      if (password === mockPassword) {
        setUser(foundUser);
        setIsAuthenticated(true);
        localStorage.setItem('exseg_user', JSON.stringify(foundUser));
        return true;
      }
    }

    return false;
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('exseg_user');
  }, []);

  const createUser = useCallback((userData: Omit<User, 'id' | 'createdAt'> & { password: string }): User => {
    const newUser: User = {
      ...userData,
      id: `user-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    usersDatabase.push(newUser);
    return newUser;
  }, []);

  const deleteUser = useCallback((userId: string): boolean => {
    const initialLength = usersDatabase.length;
    usersDatabase = usersDatabase.filter(u => u.id !== userId);
    return usersDatabase.length < initialLength;
  }, []);

  const getUsersByRole = useCallback((role: UserRole): User[] => {
    return usersDatabase.filter(u => u.role === role);
  }, []);

  const getUsersByProject = useCallback((projectId: string): User[] => {
    return usersDatabase.filter(u => u.projectIds.includes(projectId));
  }, []);

  const getAllUsers = useCallback((): User[] => {
    return usersDatabase;
  }, []);

  const updateUserProjects = useCallback((userId: string, projectIds: string[]): boolean => {
    const userIndex = usersDatabase.findIndex(u => u.id === userId);
    if (userIndex !== -1) {
      usersDatabase[userIndex].projectIds = projectIds;
      return true;
    }
    return false;
  }, []);

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated,
      login,
      logout,
      createUser,
      deleteUser,
      getUsersByRole,
      getUsersByProject,
      updateUserProjects,
      getAllUsers
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuthContext() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuthContext must be used within an AuthProvider');
  }
  return context;
}
