import type { Stream } from '@/types';

interface StreamGridProps {
  streams: Stream[];
}

export function StreamGrid({ streams }: StreamGridProps) {
  // Ensure we have exactly 8 streams, fill with empty if needed
  const displayStreams = [...streams];
  while (displayStreams.length < 8) {
    displayStreams.push({
      id: `empty-${displayStreams.length}`,
      name: 'Sem Stream',
      url: '',
      projectId: ''
    });
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 p-3 h-[calc(100vh-4rem)]">
      {displayStreams.map((stream, index) => (
        <div 
          key={stream.id} 
          className="relative bg-[hsl(var(--exseg-dark))] rounded-lg overflow-hidden shadow-lg"
        >
          {/* Stream Header */}
          <div className="absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black/70 to-transparent p-2">
            <div className="flex items-center justify-between">
              <span className="text-white text-xs font-medium truncate">
                {index + 1}. {stream.name}
              </span>
              {stream.url && (
                <span className="flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-2 w-2 rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                </span>
              )}
            </div>
          </div>

          {/* Iframe Container */}
          <div className="iframe-container h-full min-h-[200px]">
            {stream.url ? (
              <iframe
                src={stream.url}
                title={stream.name}
                allowFullScreen
                sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
                loading="lazy"
              />
            ) : (
              <div className="flex items-center justify-center h-full text-[hsl(var(--exseg-gray))]">
                <div className="text-center">
                  <div className="text-4xl mb-2">📹</div>
                  <p className="text-sm">Stream não configurada</p>
                </div>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
