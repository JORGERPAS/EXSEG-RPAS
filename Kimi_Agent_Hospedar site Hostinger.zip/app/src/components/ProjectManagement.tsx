import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Trash2, FolderOpen, Video, Users } from 'lucide-react';
import { useProjectsContext } from '@/contexts/ProjectsContext';
import { useAuthContext } from '@/contexts/AuthContext';

export function ProjectManagement() {
  const { projects, createProject, deleteProject, getAllStreams } = useProjectsContext();
  const { getUsersByProject } = useAuthContext();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newProject, setNewProject] = useState({
    name: '',
    description: '',
    streamIds: [] as string[]
  });

  const allStreams = getAllStreams();

  const handleCreateProject = () => {
    if (!newProject.name) return;
    
    createProject(newProject.name, newProject.description, newProject.streamIds);
    setNewProject({ name: '', description: '', streamIds: [] });
    setIsDialogOpen(false);
  };

  const handleDeleteProject = (projectId: string) => {
    deleteProject(projectId);
  };

  const toggleStream = (streamId: string) => {
    setNewProject(prev => ({
      ...prev,
      streamIds: prev.streamIds.includes(streamId)
        ? prev.streamIds.filter(id => id !== streamId)
        : [...prev.streamIds, streamId]
    }));
  };

  return (
    <div className="space-y-6">
      <Card className="border-[hsl(var(--exseg-gold))]/20">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <FolderOpen className="h-5 w-5 text-[hsl(var(--exseg-gold))]" />
            Gerenciamento de Projetos
          </CardTitle>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-[hsl(var(--exseg-gold))] hover:bg-[hsl(var(--exseg-gold-dark))] text-white">
                <Plus className="h-4 w-4 mr-2" />
                Novo Projeto
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Criar Novo Projeto</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Nome do Projeto</Label>
                  <Input
                    value={newProject.name}
                    onChange={(e) => setNewProject({ ...newProject, name: e.target.value })}
                    placeholder="Digite o nome do projeto"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Descrição</Label>
                  <Input
                    value={newProject.description}
                    onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
                    placeholder="Digite a descrição"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Streams do Projeto</Label>
                  <div className="border rounded-lg p-3 space-y-2 max-h-48 overflow-y-auto">
                    {allStreams.map((stream) => (
                      <div key={stream.id} className="flex items-center gap-2">
                        <Checkbox
                          id={stream.id}
                          checked={newProject.streamIds.includes(stream.id)}
                          onCheckedChange={() => toggleStream(stream.id)}
                        />
                        <Label htmlFor={stream.id} className="text-sm cursor-pointer">
                          {stream.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
                <Button 
                  onClick={handleCreateProject}
                  className="w-full bg-[hsl(var(--exseg-gold))] hover:bg-[hsl(var(--exseg-gold-dark))] text-white"
                >
                  Criar Projeto
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Streams</TableHead>
                <TableHead>Usuários</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {projects.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-[hsl(var(--exseg-gray))]">
                    Nenhum projeto cadastrado
                  </TableCell>
                </TableRow>
              ) : (
                projects.map((project) => {
                  const projectUsers = getUsersByProject(project.id);
                  return (
                    <TableRow key={project.id}>
                      <TableCell className="font-medium">{project.name}</TableCell>
                      <TableCell className="max-w-xs truncate">{project.description}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="flex items-center gap-1 w-fit">
                          <Video className="h-3 w-3" />
                          {project.streams.length}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="flex items-center gap-1 w-fit">
                          <Users className="h-3 w-3" />
                          {projectUsers.length}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteProject(project.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
