import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Link2, Copy, Check, Trash2, Mail, MessageCircle } from 'lucide-react';
import { useLinksContext } from '@/contexts/LinksContext';
import { useProjectsContext } from '@/contexts/ProjectsContext';
import { useAuthContext } from '@/contexts/AuthContext';
import { CountdownTimer } from './CountdownTimer';
import type { ExpirationOption } from '@/types';

const expirationOptions: { value: ExpirationOption; label: string }[] = [
  { value: '24h', label: '24 horas' },
  { value: '3d', label: '3 dias' },
  { value: '7d', label: '7 dias' },
  { value: '30d', label: '30 dias' },
  { value: '90d', label: '90 dias' },
  { value: '6m', label: '6 meses' },
  { value: '1y', label: '1 ano' },
  { value: 'unlimited', label: 'Tempo indeterminado' },
];

interface LinkGeneratorProps {
  projectId?: string;
}

export function LinkGenerator({ projectId }: LinkGeneratorProps) {
  const { generateLink, deleteLink, getLinksByCreator } = useLinksContext();
  const { getAllStreams, getProjectById } = useProjectsContext();
  const { user } = useAuthContext();
  
  const [selectedStream, setSelectedStream] = useState<string>('');
  const [selectedExpiration, setSelectedExpiration] = useState<ExpirationOption>('24h');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [generatedLinks, setGeneratedLinks] = useState(() => 
    user ? getLinksByCreator(user.id) : []
  );

  const streams = projectId 
    ? getProjectById(projectId)?.streams || []
    : getAllStreams();

  const handleGenerateLink = () => {
    if (!selectedStream || !user) return;
    
    const stream = streams.find(s => s.id === selectedStream);
    if (!stream) return;

    const newLink = generateLink(stream, selectedExpiration, user.id);
    setGeneratedLinks([...generatedLinks, newLink]);
    setSelectedStream('');
  };

  const handleDeleteLink = (linkId: string) => {
    deleteLink(linkId);
    setGeneratedLinks(generatedLinks.filter(l => l.id !== linkId));
  };

  const handleCopyLink = (link: { token: string; id: string }) => {
    const fullUrl = `${window.location.origin}/stream/${link.token}`;
    navigator.clipboard.writeText(fullUrl);
    setCopiedId(link.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShareEmail = (link: { token: string; streamName: string }) => {
    const fullUrl = `${window.location.origin}/stream/${link.token}`;
    const subject = encodeURIComponent(`Acesso à Stream ${link.streamName} - EXSEG RPAS`);
    const body = encodeURIComponent(`Olá,\n\nVocê recebeu acesso à stream ${link.streamName} do sistema EXSEG RPAS.\n\nLink de acesso: ${fullUrl}\n\nEste link expira em breve.\n\nAtenciosamente,\nEquipe EXSEG`);
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  };

  const handleShareWhatsApp = (link: { token: string; streamName: string }) => {
    const fullUrl = `${window.location.origin}/stream/${link.token}`;
    const text = encodeURIComponent(`Acesso à Stream ${link.streamName} - EXSEG RPAS\n\nLink: ${fullUrl}`);
    window.open(`https://wa.me/?text=${text}`, '_blank');
  };

  const getFullUrl = (token: string) => `${window.location.origin}/stream/${token}`;

  return (
    <div className="space-y-6">
      {/* Generate Link Form */}
      <Card className="border-[hsl(var(--exseg-gold))]/20">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Link2 className="h-5 w-5 text-[hsl(var(--exseg-gold))]" />
            Gerar Link de Acesso
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Stream</Label>
              <Select value={selectedStream} onValueChange={setSelectedStream}>
                <SelectTrigger className="border-[hsl(var(--exseg-gold))]/30">
                  <SelectValue placeholder="Selecione uma stream" />
                </SelectTrigger>
                <SelectContent>
                  {streams.map((stream) => (
                    <SelectItem key={stream.id} value={stream.id}>
                      {stream.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Validade do Link</Label>
              <Select value={selectedExpiration} onValueChange={(v) => setSelectedExpiration(v as ExpirationOption)}>
                <SelectTrigger className="border-[hsl(var(--exseg-gold))]/30">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {expirationOptions.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button
            onClick={handleGenerateLink}
            disabled={!selectedStream}
            className="w-full bg-gradient-to-r from-[hsl(var(--exseg-gold))] to-[hsl(var(--exseg-gold-light))] hover:from-[hsl(var(--exseg-gold-dark))] hover:to-[hsl(var(--exseg-gold))] text-white"
          >
            <Link2 className="h-4 w-4 mr-2" />
            Gerar Link
          </Button>
        </CardContent>
      </Card>

      {/* Generated Links List */}
      {generatedLinks.length > 0 && (
        <Card className="border-[hsl(var(--exseg-gold))]/20">
          <CardHeader>
            <CardTitle className="text-lg">Links Gerados</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {generatedLinks.map((link) => (
                <div 
                  key={link.id} 
                  className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-[hsl(var(--muted))] rounded-lg"
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-[hsl(var(--exseg-dark))] truncate">
                      {link.streamName}
                    </p>
                    <p className="text-xs text-[hsl(var(--exseg-gray))] truncate">
                      {getFullUrl(link.token)}
                    </p>
                    <div className="mt-1">
                      <CountdownTimer expiresAt={link.expiresAt} />
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleShareEmail(link)}
                      className="border-blue-500/30 text-blue-600 hover:bg-blue-50"
                    >
                      <Mail className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleShareWhatsApp(link)}
                      className="border-green-500/30 text-green-600 hover:bg-green-50"
                    >
                      <MessageCircle className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCopyLink(link)}
                      className="border-[hsl(var(--exseg-gold))]/30"
                    >
                      {copiedId === link.id ? (
                        <Check className="h-4 w-4 text-green-600" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDeleteLink(link.id)}
                      className="border-red-500/30 text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
