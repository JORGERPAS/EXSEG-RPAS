import React from 'react';
import { Button } from '@/components/ui/button';
import { LogOut, User, Shield } from 'lucide-react';
import type { UserRole } from '@/types';

interface HeaderProps {
  userName: string;
  userRole: UserRole;
  onLogout: () => void;
}

const roleLabels: Record<UserRole, string> = {
  superadmin: 'Super Administrador',
  admin: 'Administrador',
  pilot: 'Piloto'
};

const roleIcons: Record<UserRole, React.ReactNode> = {
  superadmin: <Shield className="h-4 w-4 text-[hsl(var(--exseg-gold))]" />,
  admin: <Shield className="h-4 w-4 text-[hsl(var(--exseg-blue))]" />,
  pilot: <User className="h-4 w-4 text-[hsl(var(--exseg-gray))]" />
};

export function Header({ userName, userRole, onLogout }: HeaderProps) {
  return (
    <header className="bg-white shadow-exseg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <img 
              src="/logo-exseg.png" 
              alt="EXSEG Logo" 
              className="h-10 object-contain"
            />
            <div className="hidden sm:block">
              <h1 className="text-lg font-bold text-[hsl(var(--exseg-dark))]">
                EXSEG RPAS
              </h1>
              <p className="text-xs text-[hsl(var(--exseg-gray))]">
                Monitoramento de Operações
              </p>
            </div>
          </div>

          {/* User Info & Logout */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-[hsl(var(--muted))] px-3 py-1.5 rounded-full">
              {roleIcons[userRole]}
              <div className="hidden sm:block text-sm">
                <span className="font-medium text-[hsl(var(--exseg-dark))]">{userName}</span>
                <span className="text-[hsl(var(--exseg-gray))] mx-1">|</span>
                <span className="text-xs text-[hsl(var(--exseg-gray))]">{roleLabels[userRole]}</span>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onLogout}
              className="text-[hsl(var(--exseg-gray))] hover:text-red-600 hover:bg-red-50"
            >
              <LogOut className="h-4 w-4 sm:mr-2" />
              <span className="hidden sm:inline">Sair</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
