import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Trash2, Users, UserPlus, Link2 } from 'lucide-react';
import { useAuthContext } from '@/contexts/AuthContext';
import { useProjectsContext } from '@/contexts/ProjectsContext';
import type { UserRole, User } from '@/types';

const roleLabels: Record<UserRole, string> = {
  superadmin: 'Super Admin',
  admin: 'Administrador',
  pilot: 'Piloto'
};

const roleColors: Record<UserRole, string> = {
  superadmin: 'bg-purple-100 text-purple-800',
  admin: 'bg-blue-100 text-blue-800',
  pilot: 'bg-green-100 text-green-800'
};

interface UserManagementProps {
  roleFilter?: UserRole;
}

export function UserManagement({ roleFilter }: UserManagementProps) {
  const { createUser, deleteUser, getAllUsers } = useAuthContext();
  const { projects } = useProjectsContext();
  
  const [users, setUsers] = useState<User[]>(getAllUsers());
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newUser, setNewUser] = useState({
    username: '',
    password: '',
    name: '',
    role: 'admin' as UserRole,
    projectIds: [] as string[]
  });

  const filteredUsers = roleFilter 
    ? users.filter(u => u.role === roleFilter)
    : users;

  const handleCreateUser = () => {
    if (!newUser.username || !newUser.password || !newUser.name) return;
    
    const created = createUser({
      username: newUser.username,
      password: newUser.password,
      name: newUser.name,
      role: newUser.role,
      projectIds: newUser.projectIds
    });
    
    setUsers([...users, created]);
    setNewUser({ username: '', password: '', name: '', role: 'admin', projectIds: [] });
    setIsDialogOpen(false);
  };

  const handleDeleteUser = (userId: string) => {
    deleteUser(userId);
    setUsers(users.filter(u => u.id !== userId));
  };

  const generateInviteLink = (user: User) => {
    const inviteData = {
      userId: user.id,
      username: user.username,
      role: user.role,
      projects: user.projectIds,
      timestamp: Date.now()
    };
    const encoded = btoa(JSON.stringify(inviteData));
    const link = `${window.location.origin}/invite/${encoded}`;
    navigator.clipboard.writeText(link);
    alert('Link de convite copiado para a área de transferência!');
  };

  return (
    <Card className="border-[hsl(var(--exseg-gold))]/20">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg flex items-center gap-2">
          <Users className="h-5 w-5 text-[hsl(var(--exseg-gold))]" />
          Gerenciamento de Usuários
        </CardTitle>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[hsl(var(--exseg-gold))] hover:bg-[hsl(var(--exseg-gold-dark))] text-white">
              <UserPlus className="h-4 w-4 mr-2" />
              Novo Usuário
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Cadastrar Novo Usuário</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Nome Completo</Label>
                <Input
                  value={newUser.name}
                  onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                  placeholder="Digite o nome"
                />
              </div>
              <div className="space-y-2">
                <Label>Usuário</Label>
                <Input
                  value={newUser.username}
                  onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
                  placeholder="Digite o usuário"
                />
              </div>
              <div className="space-y-2">
                <Label>Senha</Label>
                <Input
                  type="password"
                  value={newUser.password}
                  onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                  placeholder="Digite a senha"
                />
              </div>
              <div className="space-y-2">
                <Label>Perfil</Label>
                <Select 
                  value={newUser.role} 
                  onValueChange={(v) => setNewUser({ ...newUser, role: v as UserRole })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Administrador</SelectItem>
                    <SelectItem value="pilot">Piloto</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Projetos</Label>
                <Select 
                  value={newUser.projectIds[0] || ''} 
                  onValueChange={(v) => setNewUser({ ...newUser, projectIds: v ? [v] : [] })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um projeto" />
                  </SelectTrigger>
                  <SelectContent>
                    {projects.map((project) => (
                      <SelectItem key={project.id} value={project.id}>
                        {project.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button 
                onClick={handleCreateUser}
                className="w-full bg-[hsl(var(--exseg-gold))] hover:bg-[hsl(var(--exseg-gold-dark))] text-white"
              >
                Cadastrar
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>Usuário</TableHead>
              <TableHead>Perfil</TableHead>
              <TableHead>Projetos</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredUsers.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-[hsl(var(--exseg-gray))]">
                  Nenhum usuário cadastrado
                </TableCell>
              </TableRow>
            ) : (
              filteredUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium">{user.name}</TableCell>
                  <TableCell>{user.username}</TableCell>
                  <TableCell>
                    <Badge className={roleColors[user.role]}>
                      {roleLabels[user.role]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {user.projectIds.includes('all') 
                      ? 'Todos' 
                      : user.projectIds.length.toString()
                    }
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => generateInviteLink(user)}
                        className="text-[hsl(var(--exseg-blue))]"
                      >
                        <Link2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteUser(user.id)}
                        className="text-red-600"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
