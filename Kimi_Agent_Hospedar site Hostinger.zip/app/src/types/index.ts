// User Types
export type UserRole = 'superadmin' | 'admin' | 'pilot';

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  projectIds: string[];
  createdAt: string;
}

// Project Types
export interface Project {
  id: string;
  name: string;
  description: string;
  streams: Stream[];
  createdAt: string;
}

export interface Stream {
  id: string;
  name: string;
  url: string;
  projectId: string;
}

// Link Types
export type ExpirationOption = '24h' | '3d' | '7d' | '30d' | '90d' | '6m' | '1y' | 'unlimited';

export interface GeneratedLink {
  id: string;
  streamId: string;
  streamName: string;
  token: string;
  expiresAt: string | null;
  createdAt: string;
  createdBy: string;
}

// Auth Types
export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
}

// Form Types
export interface CreateUserForm {
  username: string;
  password: string;
  name: string;
  role: UserRole;
  projectIds: string[];
}

export interface CreateProjectForm {
  name: string;
  description: string;
}

// Dashboard Types
export interface DashboardLayout {
  id: string;
  name: string;
  streams: Stream[];
}
