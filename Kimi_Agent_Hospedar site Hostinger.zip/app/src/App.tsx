import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { LoginForm } from '@/components/LoginForm';
import { SuperAdminDashboard } from '@/pages/SuperAdminDashboard';
import { AdminDashboard } from '@/pages/AdminDashboard';
import { PilotDashboard } from '@/pages/PilotDashboard';
import { PublicStream } from '@/pages/PublicStream';
import { useAuthContext } from '@/contexts/AuthContext';
import { AuthProvider } from '@/contexts/AuthContext';
import { ProjectsProvider } from '@/contexts/ProjectsContext';
import { LinksProvider } from '@/contexts/LinksContext';
import type { UserRole } from '@/types';

function ProtectedRoute({ 
  children, 
  allowedRoles 
}: { 
  children: React.ReactNode; 
  allowedRoles: UserRole[];
}) {
  const { isAuthenticated, user } = useAuthContext();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (user && !allowedRoles.includes(user.role)) {
    // Redirect to appropriate dashboard based on role
    if (user.role === 'superadmin') {
      return <Navigate to="/superadmin" replace />;
    } else if (user.role === 'admin') {
      return <Navigate to="/admin" replace />;
    } else if (user.role === 'pilot') {
      return <Navigate to="/pilot" replace />;
    }
  }

  return <>{children}</>;
}

function PublicRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, user } = useAuthContext();

  if (isAuthenticated && user) {
    if (user.role === 'superadmin') {
      return <Navigate to="/superadmin" replace />;
    } else if (user.role === 'admin') {
      return <Navigate to="/admin" replace />;
    } else if (user.role === 'pilot') {
      return <Navigate to="/pilot" replace />;
    }
  }

  return <>{children}</>;
}

function AppRoutes() {
  const { login } = useAuthContext();

  return (
    <Routes>
      {/* Public Routes */}
      <Route 
        path="/login" 
        element={
          <PublicRoute>
            <LoginForm onLogin={login} />
          </PublicRoute>
        } 
      />
      
      {/* Public Stream Route */}
      <Route path="/stream/:token" element={<PublicStream />} />
      
      {/* Invite Route (for future implementation) */}
      <Route 
        path="/invite/:code" 
        element={
          <div className="min-h-screen flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-2xl font-bold mb-4">Convite Processado</h1>
              <p>Redirecionando...</p>
            </div>
          </div>
        } 
      />

      {/* Protected Routes */}
      <Route 
        path="/superadmin" 
        element={
          <ProtectedRoute allowedRoles={['superadmin']}>
            <SuperAdminDashboard />
          </ProtectedRoute>
        } 
      />
      
      <Route 
        path="/admin" 
        element={
          <ProtectedRoute allowedRoles={['admin', 'superadmin']}>
            <AdminDashboard />
          </ProtectedRoute>
        } 
      />
      
      <Route 
        path="/pilot" 
        element={
          <ProtectedRoute allowedRoles={['pilot', 'admin', 'superadmin']}>
            <PilotDashboard />
          </ProtectedRoute>
        } 
      />

      {/* Default Route */}
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <ProjectsProvider>
        <LinksProvider>
          <Router>
            <AppRoutes />
          </Router>
        </LinksProvider>
      </ProjectsProvider>
    </AuthProvider>
  );
}

export default App;
